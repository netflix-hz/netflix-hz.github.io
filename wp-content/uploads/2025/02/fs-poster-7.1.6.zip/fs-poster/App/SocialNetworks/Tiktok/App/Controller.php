<?php

namespace FSPoster\App\SocialNetworks\Tiktok\App;

use FSPoster\App\Providers\Core\RestRequest;
use FSPoster\App\Providers\Core\Settings;

class Controller
{

    public static function saveSettings ( RestRequest $request ): array
    {
        $postText = $request->param( 'post_text', '', RestRequest::TYPE_STRING );
        $privacyLevel = $request->param( 'privacy_level', '', RestRequest::TYPE_STRING );
        $disableDuet = $request->param( 'disable_duet', '', RestRequest::TYPE_BOOL );
        $disableComment = $request->param( 'disable_comment', '', RestRequest::TYPE_BOOL );
        $disableStitch = $request->param( 'disable_stitch', '', RestRequest::TYPE_BOOL );

	    $allowedPrivacyLevels = [
		    'PUBLIC_TO_EVERYONE',
		    'MUTUAL_FOLLOW_FRIENDS',
		    'FOLLOWER_OF_CREATOR',
		    'SELF_ONLY'
	    ];

	    $privacyLevel = in_array( $privacyLevel, $allowedPrivacyLevels ) ? $privacyLevel : $allowedPrivacyLevels[0];

        Settings::set( 'tiktok_post_content', $postText );
        Settings::set( 'tiktok_privacy_level', $privacyLevel );
        Settings::set( 'tiktok_disable_duet', $disableDuet );
        Settings::set( 'tiktok_disable_comment', $disableComment );
        Settings::set( 'tiktok_disable_stitch', $disableStitch );

	    do_action( 'fsp_save_settings', $request, Bootstrap::getInstance()->getSlug() );

        return [];
    }

    public static function getSettings ( RestRequest $request ): array
    {
	    return apply_filters('fsp_get_settings', [
		    'post_text'             => Settings::get( 'tiktok_post_content', '{post_title}' ),
		    'privacy_level'         => Settings::get( 'tiktok_privacy_level', 'PUBLIC_TO_EVERYONE' ),
		    'disable_duet'          => Settings::get( 'tiktok_disable_duet', false ),
		    'disable_comment'       => Settings::get( 'tiktok_disable_comment', false ),
		    'disable_stitch'        => Settings::get( 'tiktok_disable_stitch', false ),
	    ], Bootstrap::getInstance()->getSlug());
    }

}